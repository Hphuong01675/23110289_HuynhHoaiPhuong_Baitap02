package Controller;

import Model.User;
import Service.UserService;
import Service.UserServiceImpl;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;
import java.io.IOException;

@WebServlet("/login")
public class LoginServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;
    private UserService service = new UserServiceImpl();

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        String username = request.getParameter("username");
        String password = request.getParameter("password");

        User user = service.login(username, password);

        if (user != null) {
            // Lưu user vào session
            HttpSession session = request.getSession();
            session.setAttribute("user", user);

            // Chuyển hướng sang trang welcome.jsp (tạo file mới)
            response.sendRedirect(request.getContextPath() + "/Views/Welcome.jsp");
        } else {
            // Sai tài khoản hoặc mật khẩu
            request.setAttribute("error", "Tên đăng nhập hoặc mật khẩu không đúng!");
            request.getRequestDispatcher("/Views/Login.jsp").forward(request, response);
        }
    }
}
