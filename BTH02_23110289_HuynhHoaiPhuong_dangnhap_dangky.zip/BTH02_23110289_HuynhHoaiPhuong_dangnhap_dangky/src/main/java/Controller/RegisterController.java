package Controller;

import java.io.IOException;

import jakarta.servlet.ServletException;
import jakarta.servlet.http.*;
import Service.UserService;
import Service.UserServiceImpl;

public class RegisterController extends HttpServlet {
    private static final long serialVersionUID = 1L;

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        req.getRequestDispatcher("/views/register.jsp").forward(req, resp);
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        req.setCharacterEncoding("UTF-8");
        String username = req.getParameter("username");
        String password = req.getParameter("password");
        String fullname = req.getParameter("fullname");
        String phone = req.getParameter("phone");

        UserService service = new UserServiceImpl();
        boolean success = service.register(username, password, fullname, phone);

        if (success) {
            resp.sendRedirect(req.getContextPath() + "/login");
        } else {
            req.setAttribute("alert", "Tài khoản hoặc email đã tồn tại!");
            req.getRequestDispatcher("/views/register.jsp").forward(req, resp);
        }
    }
}
