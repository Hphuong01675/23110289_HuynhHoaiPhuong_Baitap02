import DAO.UserDao;
import DAO.UserDaoImpl;

import jakarta.servlet.*;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;
import java.io.IOException;

@WebServlet("/forgotpassword")
public class ForgotpassServlet extends HttpServlet {
    private UserDao userDao = new UserDaoImpl();

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String username = request.getParameter("username");
        String fullname = request.getParameter("fullname");
        String sdt = request.getParameter("sdt");

        try {
            boolean valid = userDao.checkUserInfo(username, fullname, sdt);
            if (valid) {
                request.getSession().setAttribute("resetUser", username);
                response.sendRedirect("ResetPassword.jsp");
            } else {
                request.setAttribute("error", "Thông tin không chính xác!");
                request.getRequestDispatcher("ForgotPassword.jsp").forward(request, response);
            }
        } catch (Exception e) {
            e.printStackTrace();
            request.setAttribute("error", "Có lỗi xảy ra!");
            request.getRequestDispatcher("ForgotPassword.jsp").forward(request, response);
        }
    }
}
