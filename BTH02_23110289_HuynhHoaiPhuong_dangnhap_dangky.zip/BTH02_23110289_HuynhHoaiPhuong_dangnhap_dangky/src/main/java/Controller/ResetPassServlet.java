import DAO.UserDao;
import DAO.UserDaoImpl;

import jakarta.servlet.*;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;
import java.io.IOException;

@WebServlet("/resetpassword")
public class ResetPasswordServlet extends HttpServlet {
    private UserDao userDao = new UserDaoImpl();

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String newpass = request.getParameter("newpass");
        String confirmpass = request.getParameter("confirmpass");

        HttpSession session = request.getSession();
        String username = (String) session.getAttribute("resetUser");

        if (username == null) {
            response.sendRedirect("ForgotPassword.jsp");
            return;
        }

        if (!newpass.equals(confirmpass)) {
            request.setAttribute("error", "Mật khẩu xác nhận không khớp!");
            request.getRequestDispatcher("ResetPassword.jsp").forward(request, response);
            return;
        }

        try {
            boolean updated = userDao.updatePassword(username, newpass);
            if (updated) {
                session.removeAttribute("resetUser");
                request.setAttribute("message", "Cập nhật mật khẩu thành công!");
            } else {
                request.setAttribute("error", "Không thể cập nhật mật khẩu!");
            }
            request.getRequestDispatcher("ResetPassword.jsp").forward(request, response);
        } catch (Exception e) {
            e.printStackTrace();
            request.setAttribute("error", "Có lỗi xảy ra!");
            request.getRequestDispatcher("ResetPassword.jsp").forward(request, response);
        }
    }
}
