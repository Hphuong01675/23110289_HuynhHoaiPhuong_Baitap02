package DAO;

import java.sql.Connection;
import java.sql.DriverManager;

public class DBConnect {
    private static final String SERVER = "hoaiphuong\\sqlexpress01";
    private static final String DB_NAME = "userdb";
    private static final String PORT = "1433";
    private static final String USER = "sa";
    private static final String PASS = "123";

    public static Connection getConnection() throws Exception {
        String url = "jdbc:sqlserver://" + SERVER + ":" + PORT + ";databaseName=" + DB_NAME
                   + ";encrypt=true;trustServerCertificate=true";
        Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
        return DriverManager.getConnection(url, USER, PASS);
    }
}
