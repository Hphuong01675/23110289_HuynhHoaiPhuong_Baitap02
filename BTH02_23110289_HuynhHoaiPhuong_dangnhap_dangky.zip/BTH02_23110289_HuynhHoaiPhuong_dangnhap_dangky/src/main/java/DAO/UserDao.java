package DAO;

import Model.User;

public interface UserDao {
    User login(String username, String password);
    boolean register(User user);
    boolean checkExistUsername(String username);
    User findByPhone(String phone); 
    boolean checkUserInfo(String username, String fullname, String sdt);
    boolean resetPassword(String username, String fullname, String sdt, String newpass);
    boolean updatePassword(String username, String newPassword);

}
